﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;

namespace particleproject
{
    class Particle
    {
        private Color ParticleColor = Color.FromArgb(0, 1, 1, 1);
        private static readonly TimeSpan LiveTime = TimeSpan.FromSeconds(4);

        
        private long BirthTime=-1;
        private static Stopwatch swGlobal;

        private PointF _location;

        private PointF _velocity;

        private static SolidBrush solidbrush = new SolidBrush(Color.Black);
        private SizeF _size;

        private Image imgSmokePSF;

        public Particle()
        {
            if (swGlobal==null || !swGlobal.IsRunning)
            {
                swGlobal=Stopwatch.StartNew();
            }

            if (BirthTime < 0)
            {
                BirthTime = GetRunningTime();
            }
            
            //imgSmokePSF=Image.FromFile(@"c:\psf.png");

        }

        private static long GetRunningTime()
        {
            return (long)(1000D*swGlobal.ElapsedTicks / Stopwatch.Frequency);
        }

        public void Rebirth(PointF loc, PointF vel)
        {
            _location = loc;
            _velocity = vel;
            _size = new SizeF(6, 6);
            BirthTime = GetRunningTime();

        }

        public bool PerformFrame()
        {
            _location.X = _location.X + _velocity.X;
            _location.Y = _location.Y + _velocity.Y;

            _velocity.X = _velocity.X * 0.99f;
            _velocity.Y = _velocity.Y * 0.99f;

            _size.Width = _size.Width * 0.99F;
            _size.Height = _size.Height * 0.99F;
            
            return (GetRunningTime()-BirthTime) > LiveTime.TotalMilliseconds;
        }

        public void Draw(out Brush Brush,out PointF Location)
        {
            double mslivetime = (GetRunningTime() - BirthTime);
            double lifetime = LiveTime.TotalMilliseconds;

            double percentlife = mslivetime / lifetime;


            //int Alphause = 255 - (int)(percentlife * 200);

            int Alphause = (int)(250 * Math.Pow(0.95, 100 * percentlife));
            int Darkenuse = (int)(50 * (100 * percentlife / (100 * percentlife + 10)));

            ParticleColor = Color.FromArgb(ParticleColor.A, (byte)Darkenuse,
                (byte)Darkenuse, (byte)Darkenuse);
            Color usecolor = Color.FromArgb(Alphause, ParticleColor);
            solidbrush.Color = usecolor;

            Brush = solidbrush;
            Location = _location;
        }
        public void Draw(Graphics g)
        {
            double mslivetime = (GetRunningTime() - BirthTime);
            double lifetime = LiveTime.TotalMilliseconds;

            double percentlife = mslivetime / lifetime;

            
            //int Alphause = 255 - (int)(percentlife * 200);

            int Alphause = (int)(250 * Math.Pow(0.95, 100 * percentlife));
            int Darkenuse = (int)(50 * (100 * percentlife / (100 * percentlife + 10)));

            ParticleColor = Color.FromArgb(ParticleColor.A, (byte)Darkenuse,
                (byte)Darkenuse, (byte)Darkenuse);
            Color usecolor = Color.FromArgb(Alphause, ParticleColor);
            solidbrush.Color = usecolor;
            //g.FillRectangle(new SolidBrush(usecolor), Location.X - 1, Location.Y - 1, 2, 2);
            g.FillEllipse(solidbrush, _location.X - 2, _location.Y - 2, 4, 4);
            //g.DrawImage(imgSmokePSF,Location);

        }


    }
}
