﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using Timer = System.Windows.Forms.Timer;

namespace particleproject
{
    public partial class DisplayForm : Form
    {
        private object _lockObj;
        private Thread GameThread;
        private Thread DrawThread;
        private readonly ProgramState pState = new ProgramState();
        private const int cParticleNumber = 500;
        private const int TotalSpeed = 2;
        private PointF origPointOfSmoke;
        private AutoResetEvent areCalcState = new AutoResetEvent(false);
        private AutoResetEvent areReDraw = new AutoResetEvent(false);
        private bool bIsRunning { get; set; }

        Image bgImage;
        private PointF velEmitter = new PointF(2, 2);

        public DisplayForm()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            origPointOfSmoke = new PointF(20, 20);
            bgImage = Image.FromFile(@"bg.jpg");
            PicParticles.Image = bgImage;
            this.Size = bgImage.Size;


            _lockObj = new object();

            GameThread = new Thread(GameProc);
            bIsRunning = true;
            GameThread.Start();

            DrawThread = new Thread(Redraw);
            DrawThread.Start();

            System.Timers.Timer emitterTrajTimer = new System.Timers.Timer(100);
            emitterTrajTimer.Elapsed += onSourceTriggered;
            emitterTrajTimer.Enabled = true;

            System.Timers.Timer particleCalcTimer = new System.Timers.Timer(25);
            particleCalcTimer.Elapsed += RecalcTimer_Elapsed;
            particleCalcTimer.Enabled = true;

            System.Timers.Timer redrawTimer = new System.Timers.Timer(25);
            redrawTimer.Elapsed += RedrawElapsed;
            redrawTimer.Enabled = true;
        }
        private void RecalcTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            areCalcState.Set();
        }

        private void RedrawElapsed(object sender, ElapsedEventArgs e)
        {
            areReDraw.Set();
        }

        private void Redraw()
        {
            while (bIsRunning)
            {
                areReDraw.WaitOne();
                lock (_lockObj)
                {
                    //Parallel.ForEach(pState.Particles, p => { p.Draw(e.Graphics); });
                    Bitmap fore = new Bitmap(bgImage, new Size(bgImage.Width, bgImage.Height));
                    foreach (Particle p in pState.Particles)
                    {
                        Brush br;
                        PointF location;
                        p.Draw(out br, out location);
                        Graphics gr = Graphics.FromImage(fore);
                        gr.FillEllipse(br, location.X - 2, location.Y - 2, 4, 4);
                    }

                    if (PicParticles.InvokeRequired)
                    {
                        PicParticles.Invoke((MethodInvoker)(
                            () => { PicParticles.Image = fore; }));
                    }
                    else
                    {
                        PicParticles.Image = fore;
                    }

                }


            }

        }


        public void GameProc()
        {

            try
            {
                while (bIsRunning)
                {
                    areCalcState.WaitOne();

                    lock (_lockObj)
                    {
                        for (int ii = pState.Particles.Count - 1; ii >= 0; ii--)
                        {
                            if (pState.Particles[ii] != null && pState.Particles[ii].PerformFrame())
                            {
                                pState.ReturnToPool(pState.Particles[ii]);
                            }

                        }
                        //Parallel.For(0, pState.Particles.Count - 1, ii =>
                        //{
                        //    if (pState.Particles[ii].PerformFrame())
                        //    {
                        //        int jj = pState.Particles.Count - 1 - ii;
                        //        pState.ReturnToPool(pState.Particles[jj]);
                        //    }
                        //});
                    }
                    Invoke((MethodInvoker)(() =>
                    {
                        PicParticles.Invalidate();
                        PicParticles.Update();
                        //PicParticles.Refresh();

                    }));


                }

            }
            catch (ThreadAbortException ex)
            {
                Debug.Print("Proc Thread aborting");

            }
        }


        private void onSourceTriggered(object sender, ElapsedEventArgs elapsedEventArgs)
        {

            PointF newPointOfSmoke = new PointF(origPointOfSmoke.X + velEmitter.X, origPointOfSmoke.Y + velEmitter.Y);
            origPointOfSmoke = newPointOfSmoke;

            BoundaryDetect();
            DrawParticleEmitter(newPointOfSmoke);
        }

        private void BoundaryDetect()
        {
            if (origPointOfSmoke.X > PicParticles.Width)
                velEmitter.X *= -1;
            else if (origPointOfSmoke.Y > PicParticles.Height)
                velEmitter.Y *= -1;
            else if (origPointOfSmoke.X < 0)
                velEmitter.X *= -1;
            else if (origPointOfSmoke.Y < 0)
                velEmitter.Y *= -1;
        }


        private void PicParticles_Paint(object sender, PaintEventArgs e)
        {
            lock (_lockObj)
            {
                //Parallel.ForEach(pState.Particles, p => { p.Draw(e.Graphics); });

                foreach (Particle p in pState.Particles)
                {
                    p.Draw(e.Graphics);

                }
            }
        }


        private void DrawParticleEmitter(PointF emitPoint)
        {

            lock (_lockObj)
            {
                //Parallel.For( 0,  cParticleNumber, ii=>
                //{
                //    Particle createparticle = pState.GetFromPool(emitPoint, TotalSpeed);
                //    if (createparticle != null)
                //    {
                //        pState.Particles.Add(createparticle);
                //    }
                //    
                //});
                for (int ii = 0; ii < cParticleNumber; ii++)
                {
                    Particle createparticle = pState.GetFromPool(emitPoint, TotalSpeed);
                    pState.Particles.Add(createparticle);
                }
            }
        }

        private void PresentationForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            GameThread.Abort();
            GameThread = null;
            DrawThread.Abort();
            DrawThread = null;
        }
    }
}
