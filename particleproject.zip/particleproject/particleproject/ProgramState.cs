﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace particleproject
{
    class ProgramState
    {
        
        public List<Particle> Particles;
        public ObjectPool<Particle> particlePool = new ObjectPool<Particle>(() => new Particle());
        private Random rg;
        public ProgramState()
        {
            Particles = new List<Particle>();
            rg = new Random();
        }


        public Particle GetFromPool(PointF emitPoint, float f)
        {
            Particle particle = particlePool.GetObject();

            particle.Rebirth(emitPoint, RandomVector(f));
            return particle;
        }

        public void ReturnToPool(Particle p)
        {
            particlePool.PutObject(p);
            Particles.Remove(p);
        }
        private PointF RandomVector(float speed)
        {
            float rangle = (float)((rg.NextDouble() * (Math.PI * 2)));

            speed *= (float)rg.NextDouble();

            return new PointF((float)Math.Cos(rangle) * speed, (float)Math.Sin(rangle) * speed);
        }
    }
}
